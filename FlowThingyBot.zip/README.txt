﻿FlowThingy AFK Bot
==================
1. Put your config.json in this folder (download from flowthingy.xyz/bot.html)
2. Double-click FlowThingyBot.exe
3. Leave the window open - your server stays online!
