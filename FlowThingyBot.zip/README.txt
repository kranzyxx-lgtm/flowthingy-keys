﻿FlowThingy AFK Bot
==================
1. Put your config.json in this folder (download from flowthingy.xyz/bot.html)
2. Double-click FlowThingyBot.exe
3. Node.js will install automatically on first run
4. Leave the window open - your server stays online!

Need help? Visit flowthingy.xyz
